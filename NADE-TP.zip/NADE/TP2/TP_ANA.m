r= 0.01;     
rho = 1.225;   
m = 0.005;       
g = 9.81;      


v0 = 0;         
tspan = [0, 60];
h = 1/80;       

n_steps = round((tspan(2) - tspan(1)) / h);

% Initialize arrays to store the results
t_Taylor = zeros(n_steps, 1);
v_Taylor = zeros(n_steps, 1);
t_Taylor(1) = tspan(1);
v_Taylor(1) = v0;

% Use the second-order Taylor method to solve the ODE
for i = 1:n_steps-1
    % Get the current time and velocity
    t = t_Taylor(i);
    v = v_Taylor(i);
    
    % Compute f(t, v) and f'(t, v) using the ode_rhs function
    [f_val, df_dt] = ode_rhs(v, r, rho, m, g);
    
    % Compute the next velocity using the second-order Taylor method
    v_next = v + h * f_val + 0.5 * h^2 * df_dt;
    
    % Store the next time and velocity
    t_Taylor(i+1) = t + h;
    v_Taylor(i+1) = v_next;
end


%ode45
[t_ode45, v_ode45] = ode45(@(t, v) ode_rhs(v, r, rho, m, g), tspan, v0);


figure;
plot(t_ode45, v_ode45, 'b-', 'LineWidth', 2); hold on;
plot(t_Taylor, v_Taylor, 'r--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Velocity (m/s)');
legend('ode45 Solution', 'Second-Order Taylor Method');
title('Comparison of Velocity Using ode45 and Second-Order Taylor Method');
grid on;


v_ode45_interp = interp1(t_ode45, v_ode45, t_Taylor, 'linear');


absolute_error = abs(v_Taylor - v_ode45_interp);


max_error = max(absolute_error);
disp(['Maximum Absolute Error: ', num2str(max_error), ' m/s']);