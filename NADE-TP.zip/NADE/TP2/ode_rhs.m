function [f_val, df_dt] = ode_rhs( v, r, rho, m, g)
    
    A = pi * r^2; 
    c = 0.225 * rho * A ;  
    
    f_val = g - (c/m) * v^2;
    
    df_dt = -2 * (c/m) * v;
end


