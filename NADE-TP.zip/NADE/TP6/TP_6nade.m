
L = 1; T = 1;
Nx = 20; Nt = 20;
dx = L / Nx;
dt = T / Nt;
alpha = 0.01;
r = alpha * dt / dx^2;

% Grid
x = linspace(0, L, Nx);
t = linspace(0, T, Nt);

% Initial condition
U = zeros(Nx, Nt);
U(1,:) = zeros(1,Nx);
U(Nt,:) = zeros(1,Nt);
 for i = 2:Nx-1
     U(i,1) = sin(pi * x(i));
 end

%U(:,1) = sin(pi * x);%by accedent

%for neumann cond

for j = 1:Nt-1
    %find initial con
    %using FDM centered
    % first line
    for i = 2:Nx-1
        U(i,j+1) = U(i,j) + r * (U(i+1,j) - 2*U(i,j) + U(i-1,j));
    end
    %last line
end

% Plotting 
[X, T] = meshgrid(x, t);
surf(X', T', U)
xlabel('x'); ylabel('t'); zlabel('U(x,t)')
title('Heat Equation with Dirichlet Boundary Conditions')
