A = zeros(5, 5);
for i = 1:5
    for j = 1:5
      A(i,j) =  i+j;
    end
end

disp(A)

f_inl = @(x) exp(-x) .* sin(x.^2) + log(x + 1);

x = 1;
disp(['Function value at x = 1: ', num2str(f_inl(x))]);
syms y(x)

% 3: Solve first ODE
ode1 = diff(y, x) == y;
cond1 = y(0) == 1;
sol1 = dsolve(ode1, cond1);
disp('Solution to ODE I: dy/dx = y');
disp(sol1);

% Solve second ODE
ode2 = diff(y, x) == (x - exp(-x)) / (y + exp(y));
cond2 = y(0) == 1;
sol2 = dsolve(ode2, cond2);
disp('Solution to ODE II: dy/dx = (x - exp(-x)) / (y + exp(y))');
disp(sol2);

% Part 4: Solve ODE using ode45
odeFun = @(x, y) 3*y - 4;
[x_vals, y_vals] = ode45(odeFun, [0, 5], 2);

% Ploting
figure;
plot(x_vals, y_vals, 'b-', 'LineWidth', 2);
xlabel('x');
ylabel('y(x)');
title('Solution of dy/dx = 3y - 4 using ode45');
grid on;
% Part 5:
time = 0:0.5:10;
value = exp(-0.5 .* time);


T = table(time', value', 'VariableNames', {'Time', 'Value'});
disp(T);

% Save as CSV
writetable(T, 'function_values.csv');

% Save workspace
save('workspace_variables.mat');

