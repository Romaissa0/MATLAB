function y = f(x)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
y = exp(-x)*sin(x^2) + log(x+1);
end

